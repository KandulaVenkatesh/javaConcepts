import { IOptions } from "./ioptions";

export interface IQuestions {
    question : string;
    options : IOptions;
    solution: number;
    userChoice: boolean;
}