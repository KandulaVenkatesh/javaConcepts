import { Injectable } from "@angular/core";
import { IQuestions } from "./iquestions";
import {HttpClient,HttpErrorResponse} from '@angular/common/http'
import {Observable} from 'rxjs/Observable'
import 'rxjs/add/operator/catch'
import 'rxjs/add/operator/do'

@Injectable()
export class QuestionService{
    private _questionUrl = './assets/questions.json';
    constructor(private _http: HttpClient){

    }
    getQuestions(): Observable<IQuestions[]>{
        return this._http.get<IQuestions[]>(this._questionUrl)
                    .do(data => console.log('All: '+ JSON.stringify(data)))
                    .catch(this.handleError);
        
    }

    private handleError(err: HttpErrorResponse){
        console.log(err.message);
        return Observable.throw(err.message);
    }
}