import { Component, Input,OnInit } from '@angular/core';
import {HttpClient,HttpErrorResponse} from '@angular/common/http'
import { IQuestions } from "./iquestions";
import { IOptions } from "./ioptions";
import { QuestionService } from "./questionService";

@Component({  
  selector: 'questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css'],
  providers: [QuestionService]
})
export class QuestionsComponent implements OnInit {
  title = 'app';
  question_num = 0;
  question:String;
  qoptions:IOptions;
  answerCount = 0;
  qlength:any;
  errorMessage : string;
  previous_image:'http://www.clker.com/cliparts/r/8/b/G/H/m/previous-button-md.png';
  pTitle = "previous";
  imageWidth: number=50;
  imageMargin = 2;
  
  Count:any;
  quizQuestion: IQuestions[];


  constructor(private _questionService: QuestionService){
    
}

  previous(){
    if(this.question_num > 0){
    this.question_num = this.question_num-1;
    this.question = this.quizQuestion[this.question_num].question
    this.qoptions = this.quizQuestion[this.question_num].options
    }
  }

  next(){
    if(this.question_num < this.qlength-1){
    this.question_num = this.question_num+1;
    this.question = this.quizQuestion[this.question_num].question
    this.qoptions = this.quizQuestion[this.question_num].options
    }
  }
  submit(event){
//debugger;
  this.Count = 0;
  this.quizQuestion.forEach(function(obj){
    console.log(obj.userChoice);
    if(obj.userChoice == true){
      this.Count = this.Count + 1;
    }
  }.bind(this)
  
  )
  }
  onClickMe(selectedOption:any){
  //debugger;
  if(this.quizQuestion[this.question_num].solution == selectedOption){
    this.quizQuestion[this.question_num].userChoice = true;
  }else{
    this.quizQuestion[this.question_num].userChoice = false;
  }
  if(this.question_num < this.qlength-1){
  
  this.question_num = this.question_num + 1;
  
  this.question = this.quizQuestion[this.question_num].question;
  this.qoptions = this.quizQuestion[this.question_num].options;
  selectedOption="";
  // event.stopImmediatePropagation();
  }
  }
  
  getData(event){
    this.question = this.quizQuestion[this.question_num].question
    this.qoptions = this.quizQuestion[this.question_num].options
    
  }


  
  
  ngOnInit() {
    //debugger;
    this._questionService.getQuestions()
    .subscribe(questions=>{
                this.quizQuestion = questions ,
                this.qlength = this.quizQuestion.length;   
                this.getData(event);
         
                }   ,
               error => this.errorMessage = <any>error); 
               console.log(this.qlength);
  }

 
  }  
  
